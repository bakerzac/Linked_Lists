#include <iostream>
#include "node.h"
#include "linked_list.h"

using namespace std;
//template <typename T>
int main(void)
{

	Linked_List<int> list;
	//list.push_back(10);
	list.push_back(11);
	list.push_back(9);
	list.push_back(32);
	list.push_back(21);
	list.MergeSort();
	//list.print();
	//list.call_funct();
	list.print();
	return 0;


}