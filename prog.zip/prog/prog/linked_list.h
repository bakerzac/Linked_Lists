#ifndef LINKED_LIST_H
#define LINKED_LIST_H
#include <string>
#include "node.h"
#include <iostream>

using namespace std;
template <class T>
class Linked_List
{
private:
	unsigned int length; // the number of nodes contained in the list

	// a pointer to the first node in the list
	// anything else you need...
public:
	Node<T>* head;
	Node<T>* end;
	Linked_List();
	~Linked_List();
	int get_length();
	// note: there is no set_length(unsigned int) (the reasoning should be intuitive)
	void print(); // output a list of all integers contained within the list
	void clear(); // delete the entire list (remove all nodes and reset length to 0)
	void push_front(T); // insert a new value at the front of the list (returns the new length of the list)
	void push_back(T); // insert a new value at the back of the list (returns the new length of the list)
	unsigned int insert(T dataIn); // insert a new value in the list at the specified index (returns the new length of the list)
	bool is_empty();
	static Node<T>* SortedMerge(Node<T>* a, Node<T>* b);
	 void MergeSort();
	static void MergeSort(Node<T>** ref);
	static void split(Node<T>* source, Node<T>** frontRef, Node<T>** backRef);
};
template <class T>
Linked_List<T>::Linked_List()
{
	head = NULL;
	end = NULL;
	length = 0;
}
template <class T>
Linked_List<T>::~Linked_List()
{
	Node<T>* currentPtr = end;
	Node<T>* tempPtr;
	while (currentPtr != nullptr)
	{
		tempPtr = currentPtr;
		currentPtr = currentPtr->nextptr;
		delete tempPtr;
	}
}
template <class T>
int Linked_List<T>::get_length()
{
	return length;
	//returns length of the list
}
// note: there is no set_length(unsigned int) (the reasoning should be intuitive)
template <class T>
void Linked_List<T>::print()
{
	if (is_empty())
	{
		cout << "The list is empty" << endl;

	}
	else
	{
		Node<T>* currentPtr = head;

		cout << "The contents of the list is: ";
		while (currentPtr != NULL) //prints until the end of the list is reached
		{
			cout << currentPtr->data << " ";
			currentPtr = currentPtr->nextptr; //moves to next node in list
		}
		cout << endl;
	}
	//check if its empty and print error 
	//else loop until the next node pointer points to NULL and print each element
}
// output a list of all integers contained within the list
template <class T>
void Linked_List<T>::clear()
{
	//deletes whole list
}
template <class T>
bool Linked_List<T>::is_empty()
{
	if (head == NULL && end == NULL)
	{
		return true;
	}
	else
	{
		return false;
	}
	//checks if the list is empty or not
}
// delete the entire list (remove all nodes and reset length to 0)
template <class T>
void Linked_List<T>::push_front(T dataIn)
{
	if (is_empty())
	{
		Node<T>* newPtr = new Node<T>(dataIn);
		head = newPtr;
		end = newPtr;
	}
	else
	{
		Node<T>* newPtr = new Node<T>(dataIn);
		newPtr->nextPtr = head;
		head = newPtr;
	}

	//check if the list is empty
	//if empty make a new pointer and set it equal to the start pointer.
	//and set the endpointer equal to the new pointer
	//if its not empty make a new pointer that points to the nextpointer found in the node class
	//set that equal to the start pointer
}
// insert a new value at the front of the list (returns the new length of the list)
template <class T>
void Linked_List<T>::push_back(T dataIn)
{
	if (is_empty())
	{
		Node<T>* newPtr = new Node<T>(dataIn);
		head = newPtr;
		end = newPtr;
	}
	else
	{
		Node<T>* newPtr = new Node<T>(dataIn);
		end->nextptr = newPtr;
		end = newPtr;
	}

	//check if the list is empty
	//if empty make a new pointer and set it equal to the start pointer and set end pointer to th4e start pointer.
	//make a new pointer and set endpointer->next pointer new pointer
}
// insert a new value at the back of the list (returns the new length of the list)
template <class T>
unsigned int Linked_List<T>::insert(T dataIn)
{
	if (is_empty())
	{
		insert(dataIn);
	}
	else
	{
		if (dataIn < head->data)
		{
			insert(dataIn);
		}
		else if (dataIn >= end->data)
		{
			insert(dataIn);
		}
		else
		{
			Node<T>* currentPtr = head;
			Node<T>* newPtr = new Node<T>(dataIn);
			while (currentPtr != end)
			{
				if ((newPtr->data < currentPtr->nextPtr->data) && (newPtr->data >= currentPtr->data))
				{
					Node<T>* next = currentPtr->nextPtr;
					currentPtr->nextPtr = newPtr;
					newPtr->nextPtr = next;
					break;
				}
				currentPtr = currentPtr->nextPtr;
			}
		}
	}
	//check if its empty
	//if empty then call push_front
	//else make a current pointer equal to the start pointer and make a new pointer equal to the input
	//while current != end and do a comparative loop for where to place the new node
	//
}

template <class T>
void  Linked_List<T>::MergeSort()
{
	Node<T>* firsthalf;
	Node<T>* secondhalf;

	if ((head) == nullptr || (head)->nextptr == nullptr) {
		return;
	}

	split(head, &firsthalf, &secondhalf);
	Linked_List::MergeSort(&firsthalf);
	Linked_List::MergeSort(&secondhalf);


	head = SortedMerge(firsthalf, secondhalf);
}

template <class T>
void Linked_List<T>::MergeSort(Node<T>** ref)
{
	Node<T>* firsthalf;
	Node<T>* secondhalf;

	if ((*ref) == nullptr || (*ref)->nextptr == nullptr) {
		return;
	}

	split(*ref, &firsthalf, &secondhalf);
	Linked_List::MergeSort(&firsthalf);
	Linked_List::MergeSort(&secondhalf);


	*ref = SortedMerge(firsthalf, secondhalf);
}
template <class T>
Node<T>* Linked_List<T>::SortedMerge(Node<T>* a, Node<T>* b)
{
	//print();
	Node<T>* result = NULL;

	if (a == NULL)
		return (b);
	else if (b == NULL)
		return (a);

	if (a->data <= b->data) {
		result = a;
		result->nextptr = SortedMerge(a->nextptr, b);
	}
	else {
		result = b;
		result->nextptr = SortedMerge(a, b->nextptr);
	}
	return (result);
}
template <class T>
void Linked_List<T>::split(Node<T>* source, Node<T>** frontRef, Node<T>** backRef)
{
	//print();
	Node<T>* fast;
	Node<T>* slow;
	slow = source;
	fast = source->nextptr;

	while (fast != NULL) {
		fast = fast->nextptr;
		if (fast != NULL) {
			slow = slow->nextptr;
			fast = fast->nextptr;
		}
	}

	*frontRef = source;
	*backRef = slow->nextptr;
	slow->nextptr = NULL;
}
// sort the nodes in descending order
// you c
#endif
