#ifndef NODE_HPP
#define NODE_HPP
template <class T>
class Linked_List;
template <class T>
class Node
{
	//friend class Linked_List;
public:
	
	Node(T dataIn);// a pointer to the next node in the list
	T data;
	Node* nextptr;
	Node();
};
template <class T>
Node<T>::Node(T dataIn)
{
	data = dataIn;
	nextptr = 0;
}
template <class T>
Node<T>::Node()
{
	data = NULL;
	nextptr = 0;
}




#endif